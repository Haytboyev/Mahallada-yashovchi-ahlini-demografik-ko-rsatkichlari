from django.apps import AppConfig


class ChartappConfig(AppConfig):
    name = 'chartapp'
